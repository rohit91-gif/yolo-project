# chair_detection > 2024-12-18 6:11pm
https://universe.roboflow.com/chair-mszlu/chair_detection-uqzuu

Provided by a Roboflow user
License: CC BY 4.0

